//
//  AppDelegate.h
//  SetGestureLock
//
//  Created by 余钦 on 16/5/6.
//  Copyright © 2016年 yuqin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

