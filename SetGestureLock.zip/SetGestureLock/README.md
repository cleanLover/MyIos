运行效果：
![image](https://github.com/Naruto-yq/GestureLock/blob/master/lockView.gif)