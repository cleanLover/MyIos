//
//  Annotation.m
//  LazyPDFKitDemo
//
//  Created by Palanisamy Easwaramoorthy on 3/3/15.
//  Copyright (c) 2015 Lazyprogram. All rights reserved.
//

#import "Annotation.h"
#import "File.h"


@implementation Annotation

@dynamic image;
@dynamic page;
@dynamic file;

@end
